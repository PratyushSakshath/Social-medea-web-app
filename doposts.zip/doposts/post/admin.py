from django.contrib import admin
from . models import post

# Register your models here.
admin.site.register(post)
